{{View:: make('title')}}

<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<div>
    <form action="register" method="post">
        @csrf


<div class="modal modal-signin position-static d-block" tabindex="-1" role="dialog" id="modalSignin">
  <div class="modal-dialog" role="document">
    <div class="modal-content rounded-5 shadow">
      <div class="modal-header p-5 pb-4 border-bottom-0">
        <!-- <h5 class="modal-title">Modal title</h5> -->
        <h2 class="fw-bold mb-0">Sign up for free</h2>
        <button type="button" onclick="javascript:history.back()" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body p-5 pt-0">

           <div class="form-floating mb-3">
            <input type="text" name="fullname" class="form-control rounded-4" id="exampleInputName1" placeholder="Full Name">
            <label for="exampleInputName1">Full name</label>
          </div>
          <div class="form-floating mb-3">
            <input type="email" name="email" class="form-control rounded-4" id="exampleInputEmail1" placeholder="name@example.com">
            <label for="exampleInputEmail1">Email address</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" name="password" class="form-control rounded-4" id="exampleInputPassword1" placeholder="Password">
            <label for="exampleInputPassword1">Password</label>
          </div>
          <button class="w-100 mb-2 btn btn-lg rounded-4 btn-primary" type="submit">Sign up</button>
          <small class="text-muted">By clicking Sign up, you agree to the terms of use.</small>
          <!-- End here below is the auto sign in -->
          <hr class="my-4">
          <h2 class="fs-5 fw-bold mb-3">Or use a third-party</h2>
          <button class="w-100 py-2 mb-2 btn btn-outline-dark rounded-4" type="submit">
            <svg class="bi me-1" width="16" height="16"><use xlink:href="#twitter"/></svg>
            Sign up with Twitter
          </button>
          <button class="w-100 py-2 mb-2 btn btn-outline-primary rounded-4" type="submit">
            <svg class="bi me-1" width="16" height="16"><use xlink:href="#facebook"/></svg>
            Sign up with Facebook
          </button>
          <button class="w-100 py-2 mb-2 btn btn-outline-secondary rounded-4" type="submit">
            <svg class="bi me-1" width="16" height="16"><use xlink:href="#github"/></svg>
            Sign up with GitHub
          </button>

      </div>
    </div>
  </div>
</div>





    </form>
</div>
{{View:: make('footer')}}

<!--
    <form action="register" method="post">
        @csrf
        
        <div>
            <label for="exampleInputName1">Full Name</label>
            <input type="text" name="fullname" id="exampleInputName1" />
        </div>

        <div>
            <label for="exampleInputEmail1">Email Address</label>
            <input type="email" name="email" id="exampleInputEmail1"
             aria-describedby="emailHelp"/>
            <div id="emailHelp">We'll never share your email with anyone else.</div>
        </div>
        <div>
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name="password" id="exampleInputPassword1" />
        </div>
        <button type="submit">Register</button>
        <button type="button" onclick="javascript:history.back()">Cancel</button>
    </form>

        -->



