@extends('header')
@section('login')
<div>
<form action="login" method="post">
@csrf




<div style="max-width: 100%;">
<div style="margin-left: auto; margin-right: auto; text-align:center; max-width:400px; border-radius: 10px; border-style: groove;">

<br/>
<div style="margin-left: auto; margin-right: auto; text-align:center; max-width:300px;">

  <form action="login" method="post">
  @csrf
    <img class="mb-4" src="/images/logo.png" alt="" width="100" height="100">
    <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

    <div class="form-floating">
      <input type="email" name="email" class="form-control" placeholder="name@example.com">
      <label for="floatingInput">Email address</label>
    </div>
    <div class="form-floating">
      <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Password</label>
    </div>

    <div>
        <br/>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2017–2021</p>
  </form>

  </div
 </div>
 </div>


@endsection
