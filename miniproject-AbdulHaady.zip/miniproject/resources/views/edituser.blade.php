{{View:: make('title')}}

<div class="container">

    <form action="useredit?rid={{ Request::get('rid') }}" method="post">
        @csrf

    <div class="modal modal-signin position-static d-block" tabindex="-1" role="dialog" >
  <div class="modal-dialog" role="document">
    <div class="modal-content rounded-5 shadow">
      <div class="modal-header p-5 pb-4 border-bottom-0">
        <!-- <h5 class="modal-title">Modal title</h5> -->
        <h2 class="fw-bold mb-0">Edit</h2>
        <button type="button" onclick="javascript:history.back()" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body p-5 pt-0">

           <div class="form-floating mb-3">
            <input maxlength="100" value="{{ $users->name }}" type="text" name="fullname" class="form-control rounded-4" id="exampleInputName1">
            <label for="exampleInputName1">Full name</label>
          </div>
          <div class="form-floating mb-3">
            <input maxlength="100" value="{{ $users->email }}" type="email" name="email" class="form-control rounded-4" id="exampleInputEmail1">
            <label for="exampleInputEmail1">Email address</label>
          </div>
          <div class="form-floating mb-3">
            <input maxlength="50" value="{{ $users->password }}" type="text" name="password" class="form-control rounded-4" id="exampleInputPassword1" >
            <label for="exampleInputPassword1">Password</label>
          </div>
          <button class="w-100 mb-2 btn btn-lg rounded-4 btn-primary" type="submit">Update</button>
          <small class="text-muted"></small>
          <!-- End here below is the auto sign in -->


      </div>
    </div>
  </div>
</div>





</div><!-- ingat yang ni -->

{{View:: make('footer')}}

<!-- original
<div class="container">

    <form action="useredit?rid={{ Request::get('rid') }}" method="post">
        @csrf
        <div>
            <label for="exampleInputName1">Full Name</label>
            <input maxlength="100" value="{{ $users->name }}" type="text" name="fullname" id="exampleInputName1">
        </div>

        <div>
            <label for="exampleInpuEmail1">Email Address</label>
            <input maxlength="100" value="{{ $users->email }}" type="email" name="email" id="exampleInputEmail1">

        </div>

        <div>
            <label for="exampleInpuPassword1">Password</label>
            <input maxlength="50" value="{{ $users->password }}" type="text" name="password" id="exampleInputPassword1">

        </div>

        <button type="submit">Update</button>
        <button type="button" onclick="javascript: history.back()">Cancel</button>

    </form>

 </div>
-->
