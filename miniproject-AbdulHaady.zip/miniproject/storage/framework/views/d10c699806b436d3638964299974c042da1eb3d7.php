<!--<?php echo e(View:: make('usermenu')); ?>-->

<!--logged in as <?php echo e(session()->get('user')->name); ?>

| <a href="/logout">Log out</a> |
 <a href="/editmyuser? rid=<?php echo e(session()->get('user')->id); ?>">Edit</a>-->


    <div>
        <table style="border: 3px; font-size: 20px;">

        <tr>
            <th rowspan="4">

                  <div style="border-radius: 20px; background-image: url('/images/background.svg');
                  background-position: center;  width: 400px; height: 400px; border: 5px solid grey;">
                  </div>

            </th>
            <th  colspan="4"; style="text-align: center; width: 60%" >Welcome Back <?php echo e(session()->get('user')->name); ?> !</th>

        </tr>

        <tr >
            <td style="text-align: center; ">User Name:</td>
            <td style="text-align: left;"><?php echo e(session()->get('user')->name); ?></td>
        </tr>

        <tr >
            <td style="text-align: center;">E-mail:</td>
            <td style="text-align: left;"><?php echo e(session()->get('user')->email); ?></td>
        </tr>

        <tr >
            <td>                </td>

            <td>
            <div >
                <a href="/editmyuser? rid=<?php echo e(session()->get('user')->id); ?>"><button type="button" class="btn btn-primary">Edit Details</button></a>
            </div>
            </td>
        </tr>

    </table>
    </div>
<?php /**PATH D:\xampp\htdocs\miniproject\resources\views/user.blade.php ENDPATH**/ ?>