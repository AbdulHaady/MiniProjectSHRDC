
<div class="px-3 py-2 border-bottom mb-3">
    <div style="margin-left: auto; margin-right: auto; text-align:center;">
        <form action="userlist" method="post">
            <?php echo csrf_field(); ?>
            <tr>
                <th>
                    <input value="<?php echo e(request()->input('search')); ?>" name="search" type="search" placeholder="Search..." aria-label="Search">
                </th>
                <th>
                    <button type="submit" class="btn btn-light text-dark me-2">Search</button>
                </th>

            </tr>

        </form>

    </div>
</div>



<?php /**PATH D:\xampp\htdocs\miniproject\resources\views/usermenu.blade.php ENDPATH**/ ?>