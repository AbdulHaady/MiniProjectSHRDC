<html>
<head>
    <title>Mini Project</title>
</head>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/css/headers.css" rel="stylesheet">
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>



<body>
    <div class="container">
        <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
            <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none">
                <img src="/images/logo.png" width="50" height="50" /><use xlink:href="#bootstrap" /></svg>
            </a>

            <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                <li><a href="#" class="nav-link px-2 link-secondary">Home</a></li>
                <li><a href="#" class="nav-link px-2 link-dark">Features</a></li>
                <li><a href="#" class="nav-link px-2 link-dark">Pricing</a></li>
                <li><a href="#" class="nav-link px-2 link-dark">FAQs</a></li>
                <li><a href="#" class="nav-link px-2 link-dark">About</a></li>
            </ul>

            <div class="col-md-3 text-end">
                <?php if(!session()->has('user')): ?>
                <button type="button" onclick="window.location.href='/'" class="btn btn-outline-primary me-2">Login</button>
                <button type="button" onclick="window.location.href='/register'" class="btn btn-primary">Sign-up</button>
                <?php else: ?>
                <button type="button" onclick="window.location.href='/userlist'" class="btn btn-outline-primary me-2">User List</button>
                <a href="/logout"><button type="button" class="btn btn-outline-primary me-2">Logout</button></a>
                <?php endif; ?>
            </div>
        </header>
    </div>






<?php /**PATH D:\xampp\htdocs\miniproject\resources\views/title.blade.php ENDPATH**/ ?>