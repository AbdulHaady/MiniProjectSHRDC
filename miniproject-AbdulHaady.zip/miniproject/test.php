<?phpecho '<html><head></head><body>';echo 'Current PHP version what:' . phpversion();echo '</body></html>';?>
