<?phpecho '<html><head></head><body>';echo 'Current PHP version:' . phpversion();echo '</body></html>';?>
